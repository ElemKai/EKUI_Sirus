--OmniCC localization - ruRU

if GetLocale() ~= 'ruRU' then return end

local L = OMNICC_LOCALS

L.Updated = "Обновлено до v%s"
L.None = NONE
L.Pulse = "Пульс"
L.Shine = "Свечение"