--[[
	OmniCC localization - zhTW
--]]

if GetLocale() ~= 'zhTW' then return end

local L = OMNICC_LOCALS

L.Updated = "升級至 v%s"
L.None = NONE
L.Pulse = "脈衝"
L.Shine = "閃亮"